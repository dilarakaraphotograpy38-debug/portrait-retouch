# Portre Rötuş — Çevrimdışı Toplu Rötuş Yazılımı

Bulut yok. C++20 + OpenCV motor, ONNX Runtime ile AI segmentasyon (CUDA / DirectML / CoreML), Qt 6 arayüz, Photoshop UXP paneli.

## Durum (dürüst özet)
- Kod **derlenmemiş ve gerçek yüz fotoğraflarında denenmemiştir** (üretim ortamında C++ derleyici/OpenCV yoktu). İlk derlemede küçük düzeltmeler çıkması normaldir.
- Rötuş algoritmasının matematiği `tools/prototype_check.py` ile sentetik cilt üzerinde doğrulandı (gözenek korunumu 1.00, düz blur 0.04).
- Rötuş adımları **CPU'da** (OpenCV SIMD, tile'lı) çalışır; **GPU yalnızca AI segmentasyonda** kullanılır. Rötuşun CUDA/Metal backend'i sonraki iştir.
- Diş/göz/saç adımları basit yöntemlerdir; Reblum/Retouch4me seviyesi için ek model ve ince ayar gerekir.

## Derleme
Gereksinimler: CMake 3.21+, C++20 derleyici, OpenCV 4.x (imgcodecs, photo), Qt 6 (Widgets, Concurrent),
ONNX Runtime (prebuilt), isteğe bağlı Exiv2 0.28.

```
cmake -B build -DONNXRUNTIME_ROOT=/yol/onnxruntime -DPR_ORT_DML=ON      # Windows (AMD/Intel/NVIDIA)
cmake -B build -DONNXRUNTIME_ROOT=/yol/onnxruntime -DPR_ORT_CUDA=ON     # Windows/Linux NVIDIA
cmake -B build -DONNXRUNTIME_ROOT=/yol/onnxruntime -DPR_ORT_COREML=ON   # macOS
cmake --build build --config Release
```
vcpkg ile: `vcpkg install opencv4 exiv2 qtbase onnxruntime`. Provider'a uygun ONNX Runtime paketini kullanın.

## Model
`tools/export_face_parsing_onnx.py` ile BiSeNet yüz ayrıştırma ağırlıklarını ONNX'e çevirin → `models/face_parsing.onnx`.
**Lisans uyarısı:** CelebAMask-HQ ve ondan eğitilmiş açık ağırlıklar genelde ticari kullanıma kapalıdır. Ticari ürün için kendi verinizle eğitin veya ticari lisanslı model kullanın.
Model yokken yalnızca renk tabanlı cilt tespiti çalışır (göz/diş/saç maskesi olmaz).
Model sınıf haritası `ClassMap` içindedir (`segmenter.h`).

## Kullanım
- Arayüz: `PortraitRetouch` → soldan klasör, ortada Önce/Sonra, sağda sürgüler, "Klasördeki Tümünü İşle…".
- Komut satırı: `retouch-cli --in klasor --out cikti --model models/face_parsing.onnx --provider dml --skin 60`
- Photoshop: `plugins/photoshop-uxp` klasörünü UXP Developer Tool ile yükleyin; panelde `retouch-cli` yolunu girin.

## Mimari
```
Decode(CPU,N) → AI Segmentasyon(GPU, 1) → Rötuş(CPU, tile'lı) → Encode+Metadata(CPU,N)
        ↑ sınırlı kuyruklar (backpressure) + en fazla maxInFlight fotoğraf bellekte ↑
```
- Maskeler ≤1024 px'te üretilir; tile başına tam çözünürlüğe guided filter ile büyütülür.
- Frekans ayrımı: low (Gauss) guided filter ile düzeltilir, high (gözenek) aynen eklenir; leke → Telea + komşu doku klonu; otomatik dodge & burn.
- EXIF/ICC/XMP Exiv2 ile aktarılır (yoksa aktarılmaz — derlemede uyarı verir).
- Orijinaller asla ezilmez (arayüz aynı klasörü reddeder).
