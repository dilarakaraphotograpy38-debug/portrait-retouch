# Otomatik derleme (GitHub Actions)

1. GitHub'da yeni (private olabilir) bir depo olusturun, proje klasorunun icerigini yukleyin.
2. **Actions** sekmesi -> `build` calisir (Windows, macOS, Linux paralel).
3. Basarili olunca calismanin sayfasinda **Artifacts** altindan Windows/macOS paketini indirin.
4. Surum yayinlamak icin: `git tag v0.1.0 && git push --tags` -> Releases'e zip'ler eklenir.

Ilk Windows calismasi OpenCV/Exiv2'yi derledigi icin uzun surebilir (30-60 dk); sonrasi onbellekten gelir.

Notlar:
- Bu workflow CPU ONNX Runtime kullanir (macOS'ta CoreML acik). NVIDIA CUDA / Windows DirectML icin
  ONNX Runtime'in ilgili GPU paketini indirip `-DPR_ORT_CUDA=ON` / `-DPR_ORT_DML=ON` eklemek gerekir.
- Linux isi yalnizca "derleniyor mu" kontroludur (ONNX/Exiv2 kapali).
- Workflow'u ben calistiramadim; ilk calismada hata olursa log'u buraya yapistirin, duzeltelim.
