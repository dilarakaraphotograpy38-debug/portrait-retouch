"""Rotus algoritmasinin (retouch.cpp ile ayni matematik) Python referansi + sentetik dogrulama.
C++ kodunun kendisini DERLEMEZ; yalnizca algoritmanin amacina uygun calistigini kanitlar:
 - gozenek dokusu (yuksek frekans) korunuyor mu?
 - renk lekeleri / isik dengesizligi (alcak frekans) azaliyor mu?
 - sivilce benzeri noktalar siliniyor mu?
"""
import cv2, numpy as np
rng = np.random.default_rng(7)

def gauss(m, s): return cv2.GaussianBlur(m, (0, 0), s, borderType=cv2.BORDER_REFLECT)
def gray(x): return cv2.cvtColor(x, cv2.COLOR_BGR2GRAY)

def guided(I, p, r, eps):
    box = lambda m: cv2.boxFilter(m, cv2.CV_32F, (2*r+1, 2*r+1), borderType=cv2.BORDER_REFLECT)
    mI, mp, mIp, mII = box(I), box(p), box(I*p), box(I*I)
    a = (mIp - mI*mp) / (mII - mI*mI + eps)
    b = mp - a*mI
    return box(a)*I + box(b)

def guided_bgr(g, x, r, eps):
    return cv2.merge([guided(g, c, r, eps) for c in cv2.split(x)])

def spot_score(img, sigma):
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2Lab)
    L, a = lab[..., 0], lab[..., 1]
    s1, s2 = max(1.0, sigma*0.35), sigma*2.0
    return (gauss(L, s2) - gauss(L, s1))/100.0 + (gauss(a, s1) - gauss(a, s2))*(1.5/127.0)

def retouch(img, skin, sigma, k=0.5, blemish=0.5, db=0.3, tex=1.0):
    low = gauss(img, sigma); high = img - low
    eps = (0.015 + 0.08*k)**2
    lowS = gauss(guided_bgr(gray(low), low, max(2, int(sigma*2)), eps), sigma*1.2)
    res = (low + (lowS - low)*k) + high*tex
    # heal
    score = spot_score(img, sigma)
    thr = 0.04 + 0.12*(1 - blemish)
    bin_ = ((score > thr) & (skin > 0.5)).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(bin_, connectivity=8)
    minA, maxA = np.pi*(0.15*sigma)**2, np.pi*(2.5*sigma)**2
    keep = np.zeros(n, np.uint8)
    for i in range(1, n):
        keep[i] = 255 if minA <= st[i, cv2.CC_STAT_AREA] <= maxA else 0
    spots = keep[lab]
    rad = max(1, int(sigma*0.4))
    spots = cv2.dilate(spots, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2*rad+1, 2*rad+1)))
    filled = cv2.inpaint((img*255).astype(np.uint8), spots, max(2, sigma*0.4), cv2.INPAINT_TELEA).astype(np.float32)/255
    T = np.float32([[1, 0, sigma*5], [0, 1, sigma*3]])
    shifted = cv2.warpAffine(high, T, (img.shape[1], img.shape[0]), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    healed = gauss(filled, sigma) + shifted*tex
    soft = np.clip(gauss(spots.astype(np.float32)/255, max(1.0, sigma*0.3)) * min(1, blemish*1.2), 0, 1)
    w = (soft*skin)[..., None]
    res = res*(1-w) + healed*w
    # dodge & burn
    L = gray(res); Ll = gauss(L, sigma*2); sb = sigma*8
    target = gauss(Ll*skin, sb) / (gauss(skin, sb) + 1e-3)
    delta = np.clip((target - Ll)*db, -0.06, 0.06)
    res = res + delta[..., None]
    w = skin[..., None]
    return img*(1-w) + res*w

# ---- sentetik cilt
N = 1200; sigma = 0.008*N
yy, xx = np.mgrid[0:N, 0:N].astype(np.float32)
base = np.array([0.62, 0.68, 0.82], np.float32)                        # BGR cilt tonu
blotch = gauss(rng.normal(0, 1, (N, N)).astype(np.float32), 35); blotch /= blotch.std()
light = 0.10*np.sin(xx/N*3.0) + 0.08*(yy/N - 0.5)                      # duzensiz isik
pores = rng.normal(0, 1, (N, N)).astype(np.float32); pores = gauss(pores, 1.1); pores /= pores.std()
img = base[None, None, :] + (0.035*blotch + light)[..., None]*np.array([0.6, 1.0, 1.0], np.float32)  # kirmizimsi leke
img = img + 0.02*pores[..., None]
spot_pts = []
for _ in range(14):
    cx, cy = rng.integers(150, N-150, 2); r = rng.integers(5, 9)
    m = np.exp(-(((xx-cx)**2 + (yy-cy)**2)/(2*(r*0.7)**2)))
    img[..., 2] += 0.10*m; img[..., 0] -= 0.05*m; img[..., 1] -= 0.09*m  # kirmizi-koyu nokta
    spot_pts.append((cx, cy))
img = np.clip(img, 0, 1).astype(np.float32)
skin = np.ones((N, N), np.float32)

out = retouch(img, skin, sigma)
naive = gauss(img, sigma*0.8)   # "plastik" kiyas: duz bulaniklastirma

# ---- olcumler (spot bolgeleri disinda)
mask = np.ones((N, N), bool)
for cx, cy in spot_pts: mask[max(0,cy-40):cy+40, max(0,cx-40):cx+40] = False
inner = np.zeros_like(mask); inner[100:-100, 100:-100] = True; mask &= inner
hf = lambda x: (gray(x) - gauss(gray(x), sigma*0.5))[mask].std()
lf = lambda x: gauss(gray(x), sigma*3)[mask].std()
red = lambda x: gauss(cv2.cvtColor(x, cv2.COLOR_BGR2Lab)[..., 1], sigma*3)[mask].std()
sc = lambda x: np.mean([spot_score(x, sigma)[cy-4:cy+5, cx-4:cx+5].mean() for cx, cy in spot_pts])

print(f"{'metrik':38s} {'orijinal':>10s} {'bu algoritma':>13s} {'duz blur':>10s}")
print(f"{'gozenek dokusu (yuksek frekans std)':38s} {hf(img):10.4f} {hf(out):13.4f} {hf(naive):10.4f}")
print(f"{'isik/ton dengesizligi (dusuk frek std)':38s} {lf(img):10.4f} {lf(out):13.4f} {lf(naive):10.4f}")
print(f"{'kirmizi leke dagilimi (a* dusuk frek)':38s} {red(img):10.4f} {red(out):13.4f} {red(naive):10.4f}")
print(f"{'sivilce skoru (spot merkezlerinde)':38s} {sc(img):10.4f} {sc(out):13.4f} {sc(naive):10.4f}")
print(f"\ngozenek korunma orani : {hf(out)/hf(img):.2f}  (duz blur: {hf(naive)/hf(img):.2f})")
print(f"isik dengesizligi azalma: %{100*(1-lf(out)/lf(img)):.0f}")
print(f"sivilce skoru azalma   : %{100*(1-sc(out)/sc(img)):.0f}")
