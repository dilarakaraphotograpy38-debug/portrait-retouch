"""BiSeNet yuz-ayristirma agirliklarini ONNX'e cevirir (dinamik boyut).

Kullanim:
  python export_face_parsing_onnx.py --repo <face-parsing.PyTorch klasoru> \
         --weights 79999_iter.pth --out ../models/face_parsing.onnx

UYARI (lisans): CelebAMask-HQ veri seti ve ondan egitilmis acik agirliklar
genellikle YALNIZCA arastirma/ticari-olmayan kullanima izin verir. Ticari
urun icin kendi verinle egit veya ticari kullanima acik lisansli bir model kullan.
"""
import argparse, sys, torch

ap = argparse.ArgumentParser()
ap.add_argument("--repo", required=True)
ap.add_argument("--weights", required=True)
ap.add_argument("--out", required=True)
a = ap.parse_args()

sys.path.insert(0, a.repo)
from model import BiSeNet  # zllrunning/face-parsing.PyTorch

net = BiSeNet(n_classes=19)
net.load_state_dict(torch.load(a.weights, map_location="cpu"))
net.eval()

class Wrap(torch.nn.Module):          # yalnizca ana ciktiyi dondur
    def __init__(self, m): super().__init__(); self.m = m
    def forward(self, x): return self.m(x)[0]

dummy = torch.randn(1, 3, 512, 512)
torch.onnx.export(Wrap(net), dummy, a.out, opset_version=17,
                  input_names=["input"], output_names=["logits"],
                  dynamic_axes={"input": {2: "h", 3: "w"}, "logits": {2: "h", 3: "w"}})
print("yazildi:", a.out)
