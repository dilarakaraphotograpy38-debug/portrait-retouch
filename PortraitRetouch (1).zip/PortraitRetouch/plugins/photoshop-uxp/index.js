// Photoshop UXP paneli: aktif belgeyi geçici JPEG olarak dışa aktarır,
// yerel retouch-cli'yı DIŞ SÜREÇ olarak çalıştırır, sonucu yeni belge olarak açar.
// Not: UXP, C++ kodunu doğrudan yüklemez; bu yüzden CLI + dosya yolu yaklaşımı kullanılır.
// "child_process" ve manifest'teki launchProcess izni, hedef Photoshop sürümünün
// UXP dokümantasyonuna göre doğrulanmalıdır (23.3+ ile uyumlu olması hedeflenmiştir).

const { app, core } = require("photoshop");
const { storage } = require("uxp");
const fs = storage.localFileSystem;

const $ = (id) => document.getElementById(id);
const status = (t) => ($("status").textContent = t);

for (const [id, label] of [["skin", "vSkin"], ["teeth", "vTeeth"], ["eyes", "vEyes"], ["hair", "vHair"]]) {
  $(id).addEventListener("input", () => ($(label).textContent = $(id).value));
}

// UXP file entry -> yerel dosya sistemi yolu
const nativePath = (entry) => entry.nativePath;

function runProcess(exe, args) {
  return new Promise((resolve, reject) => {
    const cp = require("child_process");
    const child = cp.spawn(exe, args);
    let out = "";
    child.stdout.on("data", (d) => (out += d));
    child.stderr.on("data", (d) => (out += d));
    child.on("error", reject);
    child.on("close", (code) => (code === 0 ? resolve(out) : reject(new Error(`Çıkış kodu ${code}\n${out}`))));
  });
}

$("run").addEventListener("click", async () => {
  const cli = $("cliPath").value.trim();
  if (!cli) return status("retouch-cli yolunu girin.");
  const doc = app.activeDocument;
  if (!doc) return status("Açık belge yok.");

  try {
    status("Dışa aktarılıyor…");
    const temp = await fs.getTemporaryFolder();
    const inDir = await temp.createFolder("pr_in_" + Date.now());
    const outDir = await temp.createFolder("pr_out_" + Date.now());
    const inFile = await inDir.createFile("source.jpg", { overwrite: true });

    await core.executeAsModal(
      async () => {
        await doc.saveAs.jpg(inFile, { quality: 12 }, true);   // kopya olarak kaydet
      },
      { commandName: "Rötuş için dışa aktar" }
    );

    status("Rötuş çalışıyor…");
    const args = [
      "--in", nativePath(inFile),
      "--out", nativePath(outDir),
      "--skin", $("skin").value, "--teeth", $("teeth").value,
      "--eyes", $("eyes").value, "--hair", $("hair").value,
      "--provider", $("provider").value,
    ];
    const model = $("modelPath").value.trim();
    if (model) args.push("--model", model);
    await runProcess(cli, args);

    status("Sonuç açılıyor…");
    const result = await outDir.getEntry("source.jpg");
    await core.executeAsModal(async () => { await app.open(result); }, { commandName: "Rötuş sonucunu aç" });
    status("Bitti.");
  } catch (e) {
    status("Hata: " + e.message);
  }
});
