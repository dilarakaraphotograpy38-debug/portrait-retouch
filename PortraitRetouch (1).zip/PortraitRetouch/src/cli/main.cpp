// retouch-cli: baslik yok (headless) toplu rotus. Photoshop eklentisi de bunu cagirir.
#include "image_io.h"
#include "pipeline.h"
#include <algorithm>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <iostream>

namespace fs = std::filesystem;

static void usage() {
  std::puts(
      "Kullanim: retouch-cli --in <dosya|klasor> --out <klasor> [secenekler]\n"
      "  --model <yol.onnx>     Yuz ayristirma modeli (yoksa klasik cilt tespiti)\n"
      "  --provider <cpu|cuda|dml|coreml>   (varsayilan: cpu)\n"
      "  --skin <0-100> --blemish <0-100> --dodgeburn <0-100>\n"
      "  --teeth <0-100> --eyes <0-100> --hair <0-100> --texture <0-100>\n"
      "  --quality <1-100>      JPEG kalitesi (varsayilan 95)\n"
      "  --threads <n>          decode/encode is parcacigi sayisi (varsayilan 2)\n"
      "  --inflight <n>         ayni anda bellekteki en fazla foto (varsayilan 4)");
}

int main(int argc, char** argv) {
  fs::path in, out;
  pr::PipelineConfig cfg;
  auto pct = [](const char* s) { return std::clamp(float(std::atof(s)) / 100.0f, 0.0f, 1.0f); };

  for (int i = 1; i < argc; ++i) {
    std::string a = argv[i];
    auto val = [&]() -> const char* { return (i + 1 < argc) ? argv[++i] : ""; };
    if (a == "--in") in = fs::u8path(val());
    else if (a == "--out") out = fs::u8path(val());
    else if (a == "--model") cfg.seg.modelPath = val();
    else if (a == "--provider") cfg.seg.provider = val();
    else if (a == "--skin") cfg.params.skinSmooth = pct(val());
    else if (a == "--blemish") cfg.params.blemishRemoval = pct(val());
    else if (a == "--dodgeburn") cfg.params.dodgeBurn = pct(val());
    else if (a == "--teeth") cfg.params.teethWhiten = pct(val());
    else if (a == "--eyes") cfg.params.eyeBrighten = pct(val());
    else if (a == "--hair") cfg.params.hairClean = pct(val());
    else if (a == "--texture") cfg.params.textureKeep = pct(val());
    else if (a == "--quality") cfg.jpegQuality = std::clamp(std::atoi(val()), 1, 100);
    else if (a == "--threads") cfg.decodeThreads = cfg.encodeThreads = std::max(1, std::atoi(val()));
    else if (a == "--inflight") cfg.maxInFlight = std::max(1, std::atoi(val()));
    else { usage(); return a == "--help" ? 0 : 2; }
  }
  if (in.empty() || out.empty()) { usage(); return 2; }

  std::vector<fs::path> files;
  if (fs::is_directory(in)) {
    for (auto& e : fs::directory_iterator(in))
      if (e.is_regular_file() && pr::isSupportedImage(e.path())) files.push_back(e.path());
    std::sort(files.begin(), files.end());
  } else if (fs::is_regular_file(in)) {
    files.push_back(in);
  }
  if (files.empty()) { std::cerr << "Islenecek goruntu bulunamadi.\n"; return 1; }

  std::atomic<bool> cancel{false};
  int failed = 0;
  try {
    pr::Pipeline pipe(cfg);
    pipe.run(files, out, [&](size_t d, size_t t, const std::string& f, bool ok, const std::string& err) {
      if (!ok) ++failed;
      std::printf("[%zu/%zu] %s %s%s\n", d, t, ok ? "OK  " : "HATA", f.c_str(), ok ? "" : (" -- " + err).c_str());
      std::fflush(stdout);
    }, cancel);
  } catch (const std::exception& e) {
    std::cerr << "Kritik hata: " << e.what() << "\n";
    return 1;
  }
  return failed ? 3 : 0;
}
