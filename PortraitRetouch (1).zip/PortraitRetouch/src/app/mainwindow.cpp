#include "mainwindow.h"
#include "image_io.h"
#include <QApplication>
#include <QDir>
#include <QFileDialog>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QImageReader>
#include <QMessageBox>
#include <QSplitter>
#include <QVBoxLayout>
#include <QtConcurrent>
#include <opencv2/imgproc.hpp>

namespace {
QImage toQImage(const cv::Mat& bgr8) {
  return QImage(bgr8.data, bgr8.cols, bgr8.rows, int(bgr8.step), QImage::Format_BGR888).copy();
}
}  // namespace

MainWindow::MainWindow() {
  setWindowTitle(QStringLiteral("Portre Rötuş — Toplu İşleme (çevrimdışı)"));
  resize(1500, 900);

  // ---- sol: klasör ağacı + liste
  fsModel_ = new QFileSystemModel(this);
  fsModel_->setRootPath(QDir::homePath());
  fsModel_->setFilter(QDir::AllDirs | QDir::NoDotAndDotDot | QDir::Drives);
  tree_ = new QTreeView;
  tree_->setModel(fsModel_);
  tree_->setRootIndex(fsModel_->index(QDir::homePath()));
  for (int c = 1; c < 4; ++c) tree_->hideColumn(c);
  tree_->setHeaderHidden(true);
  connect(tree_, &QTreeView::clicked, this, &MainWindow::onFolderSelected);

  list_ = new QListWidget;
  list_->setViewMode(QListView::IconMode);
  list_->setIconSize({96, 96});
  list_->setResizeMode(QListView::Adjust);
  list_->setMovement(QListView::Static);
  list_->setUniformItemSizes(true);
  connect(list_, &QListWidget::currentItemChanged, this, &MainWindow::onImageSelected);

  auto* leftSplit = new QSplitter(Qt::Vertical);
  leftSplit->addWidget(tree_);
  leftSplit->addWidget(list_);
  leftSplit->setSizes({300, 500});

  // ---- orta: önce/sonra
  view_ = new BeforeAfterWidget;

  // ---- sağ: ayarlar
  auto* right = new QWidget;
  auto* rl = new QVBoxLayout(right);
  auto* box = new QGroupBox(QStringLiteral("Rötuş şiddeti"));
  auto* bl = new QVBoxLayout(box);
  skin_    = addSlider(bl, QStringLiteral("Cilt Pürüzsüzlüğü"), 50);
  blemish_ = addSlider(bl, QStringLiteral("Leke / Sivilce Onarımı"), 50);
  dodge_   = addSlider(bl, QStringLiteral("Işık-Gölge Dengeleme"), 30);
  teeth_   = addSlider(bl, QStringLiteral("Diş Beyazlatma"), 30);
  eyes_    = addSlider(bl, QStringLiteral("Göz Parlatma"), 30);
  hair_    = addSlider(bl, QStringLiteral("Saç Temizleme"), 30);
  rl->addWidget(box);

  auto* mbox = new QGroupBox(QStringLiteral("AI modeli ve donanım"));
  auto* ml = new QVBoxLayout(mbox);
  modelEdit_ = new QLineEdit;
  modelEdit_->setPlaceholderText(QStringLiteral("face_parsing.onnx (boşsa klasik cilt tespiti)"));
  auto* pick = new QPushButton(QStringLiteral("Model seç…"));
  connect(pick, &QPushButton::clicked, this, &MainWindow::pickModel);
  provider_ = new QComboBox;
  provider_->addItems({"cpu", "cuda", "dml", "coreml"});
#if defined(Q_OS_WIN)
  provider_->setCurrentText("dml");
#elif defined(Q_OS_MACOS)
  provider_->setCurrentText("coreml");
#endif
  connect(provider_, &QComboBox::currentTextChanged, this, &MainWindow::rebuildSegmenter);
  ml->addWidget(modelEdit_);
  ml->addWidget(pick);
  ml->addWidget(provider_);
  rl->addWidget(mbox);

  batchBtn_ = new QPushButton(QStringLiteral("Klasördeki Tümünü İşle…"));
  cancelBtn_ = new QPushButton(QStringLiteral("İptal"));
  cancelBtn_->setEnabled(false);
  progress_ = new QProgressBar;
  status_ = new QLabel(QStringLiteral("Hazır"));
  connect(batchBtn_, &QPushButton::clicked, this, &MainWindow::startBatch);
  connect(cancelBtn_, &QPushButton::clicked, this, &MainWindow::cancelBatch);
  rl->addStretch();
  rl->addWidget(batchBtn_);
  rl->addWidget(cancelBtn_);
  rl->addWidget(progress_);
  rl->addWidget(status_);
  right->setFixedWidth(320);

  auto* split = new QSplitter(Qt::Horizontal);
  split->addWidget(leftSplit);
  split->addWidget(view_);
  split->addWidget(right);
  split->setSizes({300, 880, 320});
  setCentralWidget(split);

  debounce_.setSingleShot(true);
  debounce_.setInterval(150);
  connect(&debounce_, &QTimer::timeout, this, &MainWindow::requestRender);
  connect(&watcher_, &QFutureWatcher<cv::Mat>::finished, this, &MainWindow::onRenderDone);

  rebuildSegmenter();
}

MainWindow::~MainWindow() { cancel_ = true; joinBatch(); }

void MainWindow::joinBatch() { if (batchThread_.joinable()) batchThread_.join(); }

QSlider* MainWindow::addSlider(QLayout* l, const QString& title, int initial) {
  auto* lab = new QLabel(title);
  auto* s = new QSlider(Qt::Horizontal);
  s->setRange(0, 100);
  s->setValue(initial);
  connect(s, &QSlider::valueChanged, this, [this] { debounce_.start(); });
  l->addWidget(lab);
  l->addWidget(s);
  return s;
}

pr::RetouchParams MainWindow::currentParams() const {
  pr::RetouchParams p;
  p.skinSmooth = skin_->value() / 100.f;
  p.blemishRemoval = blemish_->value() / 100.f;
  p.dodgeBurn = dodge_->value() / 100.f;
  p.teethWhiten = teeth_->value() / 100.f;
  p.eyeBrighten = eyes_->value() / 100.f;
  p.hairClean = hair_->value() / 100.f;
  return p;
}

void MainWindow::pickModel() {
  const QString f = QFileDialog::getOpenFileName(this, "ONNX model", QString(), "ONNX (*.onnx)");
  if (f.isEmpty()) return;
  modelEdit_->setText(f);
  rebuildSegmenter();
}

void MainWindow::rebuildSegmenter() {
  pr::SegmenterConfig c;
  c.modelPath = modelEdit_->text().toStdString();
  c.provider = provider_->currentText().toStdString();
  try {
    segmenter_ = pr::makeSegmenter(c);
    status_->setText(c.modelPath.empty() ? "Klasik cilt tespiti (model yok)" : "Model yüklendi");
  } catch (const std::exception& e) {
    segmenter_ = pr::makeSegmenter({});
    QMessageBox::warning(this, "Model yüklenemedi", e.what());
  }
  if (!base_.empty()) {  // maskeleri yeni modelle yenile
    masks_ = segmenter_->segment(base_);
    requestRender();
  }
}

void MainWindow::onFolderSelected(const QModelIndex& idx) {
  currentFolder_ = fsModel_->filePath(idx);
  list_->clear();
  const QStringList filters{"*.jpg", "*.jpeg", "*.tif", "*.tiff", "*.png"};
  const auto files = QDir(currentFolder_).entryInfoList(filters, QDir::Files, QDir::Name | QDir::IgnoreCase);
  for (const QFileInfo& fi : files) {
    auto* it = new QListWidgetItem(fi.fileName());
    it->setData(Qt::UserRole, fi.absoluteFilePath());
    QImageReader rd(fi.absoluteFilePath());
    rd.setScaledSize(rd.size().scaled(96, 96, Qt::KeepAspectRatio));
    const QImage th = rd.read();
    if (!th.isNull()) it->setIcon(QPixmap::fromImage(th));
    list_->addItem(it);
  }
  status_->setText(QString("%1 fotoğraf").arg(files.size()));
}

void MainWindow::onImageSelected() {
  auto* it = list_->currentItem();
  if (!it) return;
  QApplication::setOverrideCursor(Qt::WaitCursor);
  try {
    cv::Mat full = pr::readImage(std::filesystem::path(it->data(Qt::UserRole).toString().toStdU16String()));
    cv::Mat f8;
    if (full.depth() == CV_16U) full.convertTo(f8, CV_8U, 1.0 / 257.0); else f8 = full;
    const double sc = std::min(1.0, 1600.0 / std::max(f8.cols, f8.rows));
    if (sc < 1.0) cv::resize(f8, base_, cv::Size(), sc, sc, cv::INTER_AREA); else base_ = f8.clone();
    masks_ = segmenter_->segment(base_);
    view_->setBefore(toQImage(base_));
    requestRender();
  } catch (const std::exception& e) {
    QMessageBox::warning(this, "Açılamadı", e.what());
  }
  QApplication::restoreOverrideCursor();
}

void MainWindow::requestRender() {
  if (base_.empty() || masks_.empty()) return;
  if (watcher_.isRunning()) { dirty_ = true; return; }
  const pr::RetouchParams p = currentParams();
  cv::Mat base = base_;
  pr::Masks masks = masks_;
  watcher_.setFuture(QtConcurrent::run([=] { return pr::Retoucher(p).process(base, masks); }));
}

void MainWindow::onRenderDone() {
  view_->setAfter(toQImage(watcher_.result()));
  if (dirty_) { dirty_ = false; requestRender(); }
}

void MainWindow::startBatch() {
  if (batchRunning_) return;
  if (currentFolder_.isEmpty()) { QMessageBox::information(this, "Klasör", "Önce soldan bir klasör seçin."); return; }
  const QString outDir = QFileDialog::getExistingDirectory(this, "Çıktı klasörü");
  if (outDir.isEmpty()) return;
  if (QDir(outDir) == QDir(currentFolder_)) {
    QMessageBox::warning(this, "Çıktı klasörü", "Orijinalleri ezmemek için farklı bir klasör seçin.");
    return;
  }
  std::vector<std::filesystem::path> files;
  const QStringList filters{"*.jpg", "*.jpeg", "*.tif", "*.tiff", "*.png"};
  for (const QFileInfo& fi : QDir(currentFolder_).entryInfoList(filters, QDir::Files, QDir::Name))
    files.emplace_back(fi.absoluteFilePath().toStdU16String());
  if (files.empty()) return;

  pr::PipelineConfig cfg;
  cfg.params = currentParams();
  cfg.seg.modelPath = modelEdit_->text().toStdString();
  cfg.seg.provider = provider_->currentText().toStdString();

  joinBatch();
  cancel_ = false;
  batchRunning_ = true;
  batchBtn_->setEnabled(false);
  cancelBtn_->setEnabled(true);
  progress_->setRange(0, int(files.size()));
  progress_->setValue(0);
  const auto out = std::filesystem::path(outDir.toStdU16String());

  batchThread_ = std::thread([this, cfg, files, out] {
    int failed = 0;
    try {
      pr::Pipeline pipe(cfg);
      pipe.run(files, out, [&](size_t d, size_t t, const std::string& f, bool ok, const std::string& err) {
        if (!ok) ++failed;
        const QString msg = ok ? QString("%1/%2  %3").arg(d).arg(t).arg(QString::fromStdString(f))
                               : QString("HATA: %1 — %2").arg(QString::fromStdString(f), QString::fromStdString(err));
        QMetaObject::invokeMethod(this, [this, d, msg] { progress_->setValue(int(d)); status_->setText(msg); },
                                  Qt::QueuedConnection);
      }, cancel_);
    } catch (const std::exception& e) {
      const QString m = QString::fromUtf8(e.what());
      QMetaObject::invokeMethod(this, [this, m] { QMessageBox::critical(this, "Toplu işlem hatası", m); },
                                Qt::QueuedConnection);
    }
    QMetaObject::invokeMethod(this, [this, failed] {
      batchRunning_ = false;
      batchBtn_->setEnabled(true);
      cancelBtn_->setEnabled(false);
      status_->setText(failed ? QString("Bitti — %1 hata").arg(failed) : QString("Bitti"));
    }, Qt::QueuedConnection);
  });
}

void MainWindow::cancelBatch() { cancel_ = true; status_->setText("İptal ediliyor…"); }
