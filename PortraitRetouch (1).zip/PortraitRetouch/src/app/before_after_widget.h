#pragma once
#include <QImage>
#include <QMouseEvent>
#include <QPainter>
#include <QWidget>

// Surgulu Oncesi/Sonrasi onizleme. Iki goruntu ayni boyutta olmalidir.
class BeforeAfterWidget : public QWidget {
  Q_OBJECT
 public:
  explicit BeforeAfterWidget(QWidget* parent = nullptr) : QWidget(parent) {
    setMinimumSize(480, 360);
    setCursor(Qt::SplitHCursor);
  }
  void setBefore(const QImage& b) { before_ = b; after_ = b; update(); }
  void setAfter(const QImage& a) { if (a.size() == before_.size()) { after_ = a; update(); } }

 protected:
  QRect imageRect() const {
    if (before_.isNull()) return {};
    const QSize s = before_.size().scaled(size(), Qt::KeepAspectRatio);
    return QRect(QPoint((width() - s.width()) / 2, (height() - s.height()) / 2), s);
  }
  void paintEvent(QPaintEvent*) override {
    QPainter p(this);
    p.setRenderHint(QPainter::SmoothPixmapTransform);
    p.fillRect(rect(), QColor(28, 28, 30));
    if (before_.isNull()) {
      p.setPen(QColor(150, 150, 150));
      p.drawText(rect(), Qt::AlignCenter, QStringLiteral("Soldan bir fotoğraf seçin"));
      return;
    }
    const QRect r = imageRect();
    p.drawImage(r, before_);
    const int x = r.left() + int(r.width() * split_);
    p.save();
    p.setClipRect(QRect(x, r.top(), r.right() - x + 1, r.height()));
    p.drawImage(r, after_);
    p.restore();
    p.setPen(QPen(Qt::white, 2));
    p.drawLine(x, r.top(), x, r.bottom());
    p.setBrush(Qt::white);
    p.drawEllipse(QPoint(x, r.center().y()), 9, 9);
    p.setPen(Qt::white);
    p.drawText(r.adjusted(10, 8, 0, 0), Qt::AlignLeft | Qt::AlignTop, QStringLiteral("ÖNCE"));
    p.drawText(r.adjusted(0, 8, -10, 0), Qt::AlignRight | Qt::AlignTop, QStringLiteral("SONRA"));
  }
  void mousePressEvent(QMouseEvent* e) override { moveSplit(e->position().x()); }
  void mouseMoveEvent(QMouseEvent* e) override { if (e->buttons() & Qt::LeftButton) moveSplit(e->position().x()); }
  void moveSplit(double x) {
    const QRect r = imageRect();
    if (r.isEmpty()) return;
    split_ = qBound(0.0, (x - r.left()) / r.width(), 1.0);
    update();
  }

 private:
  QImage before_, after_;
  double split_ = 0.5;
};
