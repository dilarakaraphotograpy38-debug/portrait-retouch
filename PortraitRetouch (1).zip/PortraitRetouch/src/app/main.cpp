#include "mainwindow.h"
#include <QApplication>

int main(int argc, char** argv) {
  QApplication app(argc, argv);
  app.setStyle("Fusion");
  QPalette p;
  p.setColor(QPalette::Window, QColor(38, 38, 40));
  p.setColor(QPalette::WindowText, Qt::white);
  p.setColor(QPalette::Base, QColor(28, 28, 30));
  p.setColor(QPalette::Text, Qt::white);
  p.setColor(QPalette::Button, QColor(55, 55, 58));
  p.setColor(QPalette::ButtonText, Qt::white);
  p.setColor(QPalette::Highlight, QColor(10, 132, 255));
  app.setPalette(p);
  MainWindow w;
  w.show();
  return app.exec();
}
