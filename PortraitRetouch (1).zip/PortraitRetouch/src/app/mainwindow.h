#pragma once
#include "before_after_widget.h"
#include "pipeline.h"
#include "retouch.h"
#include "segmenter.h"
#include <QComboBox>
#include <QFileSystemModel>
#include <QFutureWatcher>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMainWindow>
#include <QProgressBar>
#include <QPushButton>
#include <QSlider>
#include <QTimer>
#include <QTreeView>
#include <atomic>
#include <memory>
#include <thread>

class MainWindow : public QMainWindow {
  Q_OBJECT
 public:
  MainWindow();
  ~MainWindow() override;

 private slots:
  void onFolderSelected(const QModelIndex& idx);
  void onImageSelected();
  void requestRender();
  void onRenderDone();
  void pickModel();
  void rebuildSegmenter();
  void startBatch();
  void cancelBatch();

 private:
  QSlider* addSlider(QLayout* l, const QString& title, int initial);
  pr::RetouchParams currentParams() const;
  void joinBatch();

  QFileSystemModel* fsModel_;
  QTreeView* tree_;
  QListWidget* list_;
  BeforeAfterWidget* view_;
  QSlider *skin_, *blemish_, *dodge_, *teeth_, *eyes_, *hair_;
  QComboBox* provider_;
  QLineEdit* modelEdit_;
  QProgressBar* progress_;
  QLabel* status_;
  QPushButton *batchBtn_, *cancelBtn_;

  QString currentFolder_;
  std::unique_ptr<pr::ISegmenter> segmenter_;
  cv::Mat base_;          // onizleme (8U, <=1600 px)
  pr::Masks masks_;
  QFutureWatcher<cv::Mat> watcher_;
  QTimer debounce_;
  bool dirty_ = false;

  std::thread batchThread_;
  std::atomic<bool> cancel_{false};
  std::atomic<bool> batchRunning_{false};
};
