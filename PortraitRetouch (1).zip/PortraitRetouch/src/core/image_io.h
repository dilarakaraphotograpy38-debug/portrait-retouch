#pragma once
#include <filesystem>
#include <opencv2/core.hpp>

namespace pr {
// JPEG/TIFF/PNG okur. Unicode yollar icin dosyayi kendimiz okuyup imdecode yaparız.
// Cikti: BGR, 8U veya 16U (16-bit TIFF korunur).
cv::Mat readImage(const std::filesystem::path& p);
// Uzantiya gore yazar (.jpg/.jpeg -> 8-bit JPEG 4:4:4, .tif/.tiff -> LZW, .png).
void writeImage(const std::filesystem::path& p, const cv::Mat& img, int jpegQuality = 95);
bool isSupportedImage(const std::filesystem::path& p);
}
