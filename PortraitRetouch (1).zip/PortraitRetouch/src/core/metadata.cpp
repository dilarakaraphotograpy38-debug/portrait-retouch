#include "metadata.h"

#ifdef PR_HAS_EXIV2
#include <exiv2/exiv2.hpp>
namespace pr {
namespace {
std::string u8(const std::filesystem::path& p) {
  auto s = p.u8string();
  return std::string(reinterpret_cast<const char*>(s.c_str()), s.size());
}
}
// Exiv2 0.28 API'sine gore yazildi (setIccProfile(DataBuf&&)). 0.27 icin
// std::move'u kaldirip DataBuf'i lvalue gec ve DataBuf ctor'unda long kullan.
bool copyMetadata(const std::filesystem::path& src, const std::filesystem::path& dst) {
  try {
    auto s = Exiv2::ImageFactory::open(u8(src));
    s->readMetadata();
    auto d = Exiv2::ImageFactory::open(u8(dst));
    d->readMetadata();
    d->setExifData(s->exifData());
    d->setIptcData(s->iptcData());
    d->setXmpData(s->xmpData());
    Exiv2::ExifThumb(d->exifData()).erase();                 // eski kucuk resim gecersiz
    d->exifData()["Exif.Image.Orientation"] = uint16_t(1);
    if (s->iccProfileDefined()) {
      const Exiv2::DataBuf* icc = s->iccProfile();
      Exiv2::DataBuf copy(icc->c_data(), icc->size());
      d->setIccProfile(std::move(copy));
    }
    d->writeMetadata();
    return true;
  } catch (const std::exception&) {
    return false;
  }
}
}  // namespace pr
#else
namespace pr {
bool copyMetadata(const std::filesystem::path&, const std::filesystem::path&) { return false; }
}
#endif
