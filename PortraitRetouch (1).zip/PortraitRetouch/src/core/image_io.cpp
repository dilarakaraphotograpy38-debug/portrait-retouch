#include "image_io.h"
#include <opencv2/imgcodecs.hpp>
#include <algorithm>
#include <fstream>
#include <stdexcept>

namespace fs = std::filesystem;

namespace pr {
namespace {
std::string lowerExt(const fs::path& p) {
  std::string e = p.extension().string();
  std::transform(e.begin(), e.end(), e.begin(), [](unsigned char c) { return char(std::tolower(c)); });
  return e;
}
}  // namespace

bool isSupportedImage(const fs::path& p) {
  const auto e = lowerExt(p);
  return e == ".jpg" || e == ".jpeg" || e == ".tif" || e == ".tiff" || e == ".png";
}

cv::Mat readImage(const fs::path& p) {
  std::ifstream f(p, std::ios::binary | std::ios::ate);
  if (!f) throw std::runtime_error("Dosya acilamadi: " + p.string());
  const std::streamsize n = f.tellg();
  f.seekg(0);
  std::vector<uchar> buf(static_cast<size_t>(n));
  if (!f.read(reinterpret_cast<char*>(buf.data()), n)) throw std::runtime_error("Okuma hatasi: " + p.string());

  cv::Mat img = cv::imdecode(buf, cv::IMREAD_COLOR | cv::IMREAD_ANYDEPTH);  // EXIF yonu uygulanir
  if (img.empty()) throw std::runtime_error("Cozulemedi: " + p.string());
  if (img.depth() != CV_8U && img.depth() != CV_16U) {
    cv::Mat t;
    img.convertTo(t, CV_16U, img.depth() == CV_32F ? 65535.0 : 1.0);
    img = t;
  }
  return img;
}

void writeImage(const fs::path& p, const cv::Mat& img, int q) {
  const std::string e = lowerExt(p);
  std::vector<int> prm;
  cv::Mat out = img;
  if (e == ".jpg" || e == ".jpeg") {
    if (img.depth() == CV_16U) img.convertTo(out, CV_8U, 1.0 / 257.0);
    prm = {cv::IMWRITE_JPEG_QUALITY, q, cv::IMWRITE_JPEG_SAMPLING_FACTOR, 0x111111};  // 4:4:4
  } else if (e == ".tif" || e == ".tiff") {
    prm = {cv::IMWRITE_TIFF_COMPRESSION, 5};  // LZW
  } else if (e != ".png") {
    throw std::runtime_error("Desteklenmeyen cikti bicimi: " + e);
  }
  std::vector<uchar> buf;
  if (!cv::imencode(e, out, buf, prm)) throw std::runtime_error("Kodlama hatasi: " + p.string());
  std::ofstream f(p, std::ios::binary | std::ios::trunc);
  if (!f) throw std::runtime_error("Yazilamadi: " + p.string());
  f.write(reinterpret_cast<const char*>(buf.data()), std::streamsize(buf.size()));
}

}  // namespace pr
