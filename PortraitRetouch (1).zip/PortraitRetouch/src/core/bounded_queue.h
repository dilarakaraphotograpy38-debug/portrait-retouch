#pragma once
#include <condition_variable>
#include <deque>
#include <mutex>

namespace pr {
// Sinirli kuyruk: dolunca uretici bekler (backpressure) -> RAM sisemez.
template <class T>
class BoundedQueue {
 public:
  explicit BoundedQueue(size_t cap) : cap_(cap) {}
  bool push(T v) {
    std::unique_lock lk(m_);
    notFull_.wait(lk, [&] { return q_.size() < cap_ || closed_; });
    if (closed_) return false;
    q_.push_back(std::move(v));
    notEmpty_.notify_one();
    return true;
  }
  bool pop(T& out) {
    std::unique_lock lk(m_);
    notEmpty_.wait(lk, [&] { return !q_.empty() || closed_; });
    if (q_.empty()) return false;
    out = std::move(q_.front());
    q_.pop_front();
    notFull_.notify_one();
    return true;
  }
  void close() {
    { std::lock_guard lk(m_); closed_ = true; }
    notEmpty_.notify_all();
    notFull_.notify_all();
  }
 private:
  size_t cap_;
  std::mutex m_;
  std::condition_variable notEmpty_, notFull_;
  std::deque<T> q_;
  bool closed_ = false;
};
}  // namespace pr
