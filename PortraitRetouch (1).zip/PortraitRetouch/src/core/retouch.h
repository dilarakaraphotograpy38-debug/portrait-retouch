#pragma once
#include "types.h"

namespace pr {

// Tile tabanli, bellek-sinirli rotus motoru. Giris: BGR 8U/16U. Cikis: ayni tip.
class Retoucher {
 public:
  explicit Retoucher(RetouchParams p = {}, int tile = 1536) : p_(p), tile_(tile) {}
  cv::Mat process(const cv::Mat& src, const Masks& masks) const;
  const RetouchParams& params() const { return p_; }

 private:
  struct TileMasks { cv::Mat skin, eyes, teeth, hair, bg; };
  void processTile(cv::Mat& img, TileMasks& m, double sigma) const;
  void skinPass(cv::Mat& img, const cv::Mat& skin, double sigma) const;
  void healSpots(const cv::Mat& img, cv::Mat& res, const cv::Mat& high,
                 const cv::Mat& skin, double sigma) const;
  void dodgeBurn(cv::Mat& res, const cv::Mat& skin, double sigma) const;
  void teethPass(cv::Mat& img, const cv::Mat& teeth) const;
  void eyesPass(cv::Mat& img, const cv::Mat& eyes, double sigma) const;
  void hairPass(cv::Mat& img, const cv::Mat& hair, const cv::Mat& bg, double sigma) const;

  RetouchParams p_;
  int tile_;
};

}  // namespace pr
