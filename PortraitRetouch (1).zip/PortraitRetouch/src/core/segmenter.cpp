#include "segmenter.h"
#include <opencv2/imgproc.hpp>
#include <algorithm>
#include <array>
#include <cstring>
#include <cmath>
#include <stdexcept>

#ifdef PR_HAS_ONNX
#include <onnxruntime_cxx_api.h>
#ifdef PR_ORT_DML
#include <dml_provider_factory.h>
#endif
#ifdef PR_ORT_COREML
#include <coreml_provider_factory.h>
#endif
#endif

namespace pr {
namespace {

cv::Mat toSmall8(const cv::Mat& src, int longSide) {
  cv::Mat s8;
  if (src.depth() == CV_16U) src.convertTo(s8, CV_8U, 1.0 / 257.0);
  else s8 = src;
  const double sc = std::min(1.0, double(longSide) / std::max(src.cols, src.rows));
  if (sc >= 1.0) return s8.clone();
  cv::Mat small;
  cv::resize(s8, small, cv::Size(), sc, sc, cv::INTER_AREA);
  return small;
}

// Renk tabanli cilt tahmini (YCrCb esikleme). Yedek ve govde cildi icin.
cv::Mat classicalSkin(const cv::Mat& bgrSmall) {
  cv::Mat ycc, m;
  cv::cvtColor(bgrSmall, ycc, cv::COLOR_BGR2YCrCb);
  cv::inRange(ycc, cv::Scalar(30, 135, 85), cv::Scalar(255, 173, 127), m);
  const cv::Mat k = cv::getStructuringElement(cv::MORPH_ELLIPSE, {5, 5});
  cv::morphologyEx(m, m, cv::MORPH_OPEN, k);
  cv::morphologyEx(m, m, cv::MORPH_CLOSE, k);
  return m;
}

// Klasik yedek: yalnizca cilt maskesi uretir; goz/dis/sac/yuz bos kalir.
class ClassicSegmenter : public ISegmenter {
 public:
  explicit ClassicSegmenter(SegmenterConfig c) : cfg_(std::move(c)) {}
  Masks segment(const cv::Mat& bgr) override {
    cv::Mat small = toSmall8(bgr, cfg_.longSide);
    Masks m;
    m.skin = classicalSkin(small);
    cv::GaussianBlur(m.skin, m.skin, {7, 7}, 0);
    m.face = m.skin.clone();
    m.eyes = m.teeth = m.hair = cv::Mat::zeros(small.size(), CV_8U);
    m.background = 255 - m.skin;
    return m;
  }
 private:
  SegmenterConfig cfg_;
};

#ifdef PR_HAS_ONNX
class OnnxSegmenter : public ISegmenter {
 public:
  explicit OnnxSegmenter(SegmenterConfig c) : cfg_(std::move(c)) {
    Ort::SessionOptions so;
    so.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_ALL);
    so.SetIntraOpNumThreads(2);
    const std::string& p = cfg_.provider;
    try {
#ifdef PR_ORT_CUDA
      if (p == "cuda") { OrtCUDAProviderOptions o{}; so.AppendExecutionProvider_CUDA(o); }
#endif
#ifdef PR_ORT_DML
      if (p == "dml") {
        so.SetExecutionMode(ExecutionMode::ORT_SEQUENTIAL);
        so.DisableMemPattern();
        Ort::ThrowOnError(OrtSessionOptionsAppendExecutionProvider_DML(so, 0));
      }
#endif
#ifdef PR_ORT_COREML
      if (p == "coreml") Ort::ThrowOnError(OrtSessionOptionsAppendExecutionProvider_CoreML(so, 0));
#endif
    } catch (const std::exception&) {
      // GPU provider acilamazsa CPU'ya dus (kullanici donanimi uygun olmayabilir).
    }
#ifdef _WIN32
    std::wstring wpath(cfg_.modelPath.begin(), cfg_.modelPath.end());  // ASCII yol varsayimi
    session_ = Ort::Session(env_, wpath.c_str(), so);
#else
    session_ = Ort::Session(env_, cfg_.modelPath.c_str(), so);
#endif
    Ort::AllocatorWithDefaultOptions alloc;
    inName_  = session_.GetInputNameAllocated(0, alloc).get();
    outName_ = session_.GetOutputNameAllocated(0, alloc).get();
    auto shp = session_.GetInputTypeInfo(0).GetTensorTypeAndShapeInfo().GetShape();
    if (shp.size() == 4) {
      if (shp[2] > 0) fixedH_ = int(shp[2]);
      if (shp[3] > 0) fixedW_ = int(shp[3]);
    }
  }

  Masks segment(const cv::Mat& bgr) override {
    cv::Mat small = toSmall8(bgr, cfg_.longSide);
    auto r32 = [](int v) { return std::max(32, (v + 16) / 32 * 32); };
    const int W = fixedW_ ? fixedW_ : r32(small.cols);
    const int H = fixedH_ ? fixedH_ : r32(small.rows);

    cv::Mat net;
    cv::resize(small, net, {W, H}, 0, 0, cv::INTER_LINEAR);
    cv::cvtColor(net, net, cv::COLOR_BGR2RGB);
    net.convertTo(net, CV_32F, 1.0 / 255.0);
    const float mean[3] = {0.485f, 0.456f, 0.406f}, stdv[3] = {0.229f, 0.224f, 0.225f};
    std::vector<float> input(size_t(3) * H * W);
    std::vector<cv::Mat> planes;
    cv::split(net, planes);
    for (int c = 0; c < 3; ++c) {
      cv::Mat norm = (planes[c] - mean[c]) / stdv[c];
      std::memcpy(input.data() + size_t(c) * H * W, norm.data, size_t(H) * W * sizeof(float));
    }

    Ort::MemoryInfo mi = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
    std::array<int64_t, 4> shape{1, 3, H, W};
    Ort::Value t = Ort::Value::CreateTensor<float>(mi, input.data(), input.size(), shape.data(), 4);
    const char* inN[]  = {inName_.c_str()};
    const char* outN[] = {outName_.c_str()};
    auto out = session_.Run(Ort::RunOptions{nullptr}, inN, &t, 1, outN, 1);

    auto os = out[0].GetTensorTypeAndShapeInfo().GetShape();  // [1,C,h,w]
    if (os.size() != 4) throw std::runtime_error("Beklenmeyen model cikti boyutu");
    const int C = int(os[1]), oh = int(os[2]), ow = int(os[3]);
    const float* d = out[0].GetTensorData<float>();
    const size_t plane = size_t(oh) * ow;

    auto inSet = [](const std::vector<int>& v, int c) { return std::find(v.begin(), v.end(), c) != v.end(); };
    cv::Mat pSkin(oh, ow, CV_32F), pFace(oh, ow, CV_32F), pEyes(oh, ow, CV_32F),
            pTeeth(oh, ow, CV_32F), pHair(oh, ow, CV_32F), pBg(oh, ow, CV_32F);

    cv::parallel_for_(cv::Range(0, oh), [&](const cv::Range& rg) {
      std::vector<float> e(C);
      for (int y = rg.start; y < rg.end; ++y) {
        for (int x = 0; x < ow; ++x) {
          const size_t idx = size_t(y) * ow + x;
          float mx = -1e30f;
          for (int c = 0; c < C; ++c) mx = std::max(mx, d[c * plane + idx]);
          float sum = 0;
          for (int c = 0; c < C; ++c) { e[c] = std::exp(d[c * plane + idx] - mx); sum += e[c]; }
          float s = 0, f = 0, ey = 0, te = 0, h = 0, b = 0;
          for (int c = 0; c < C; ++c) {
            const float pr = e[c] / sum;
            if (inSet(cfg_.classes.skin, c))  s  += pr;
            if (inSet(cfg_.classes.face, c))  f  += pr;
            if (inSet(cfg_.classes.eyes, c))  ey += pr;
            if (inSet(cfg_.classes.teeth, c)) te += pr;
            if (inSet(cfg_.classes.hair, c))  h  += pr;
            if (inSet(cfg_.classes.bg, c))    b  += pr;
          }
          pSkin.at<float>(y, x) = s; pFace.at<float>(y, x) = f; pEyes.at<float>(y, x) = ey;
          pTeeth.at<float>(y, x) = te; pHair.at<float>(y, x) = h; pBg.at<float>(y, x) = b;
        }
      }
    });

    auto fin = [&](const cv::Mat& p) {
      cv::Mat up, u8;
      cv::resize(p, up, small.size(), 0, 0, cv::INTER_LINEAR);
      up.convertTo(u8, CV_8U, 255.0);
      return u8;
    };
    Masks m;
    m.skin = fin(pSkin); m.face = fin(pFace); m.eyes = fin(pEyes);
    m.teeth = fin(pTeeth); m.hair = fin(pHair); m.background = fin(pBg);

    if (cfg_.bodySkin) extendBodySkin(small, m);
    return m;
  }

 private:
  // Renkle bulunan cilt bolgelerinden yalnizca model cildiyle KESISENLERI ekler
  // (arka plandaki ahsap/duvar gibi cilt rengi nesneleri eklememek icin).
  void extendBodySkin(const cv::Mat& small, Masks& m) {
    cv::Mat cs = classicalSkin(small);
    cv::Mat labels;
    const int n = cv::connectedComponents(cs, labels, 8, CV_32S);
    std::vector<uchar> keep(n, 0);
    for (int y = 0; y < labels.rows; ++y) {
      const int* lp = labels.ptr<int>(y);
      const uchar* sp = m.skin.ptr<uchar>(y);
      for (int x = 0; x < labels.cols; ++x)
        if (lp[x] > 0 && sp[x] > 200) keep[lp[x]] = 255;
    }
    cv::Mat body(cs.size(), CV_8U, cv::Scalar(0));
    for (int y = 0; y < labels.rows; ++y) {
      const int* lp = labels.ptr<int>(y);
      uchar* bp = body.ptr<uchar>(y);
      for (int x = 0; x < labels.cols; ++x) bp[x] = lp[x] > 0 ? keep[lp[x]] : 0;
    }
    cv::GaussianBlur(body, body, {7, 7}, 0);
    cv::Mat excl = m.hair | m.eyes | m.teeth;           // bunlar cilt sayilmaz
    cv::Mat allowed = 255 - excl;
    cv::Mat bodyOnly;
    cv::bitwise_and(body, allowed, bodyOnly);
    cv::max(m.skin, bodyOnly, m.skin);
  }

  SegmenterConfig cfg_;
  Ort::Env env_{ORT_LOGGING_LEVEL_WARNING, "portrait-retouch"};
  Ort::Session session_{nullptr};
  std::string inName_, outName_;
  int fixedW_ = 0, fixedH_ = 0;
};
#endif  // PR_HAS_ONNX

}  // namespace

std::unique_ptr<ISegmenter> makeSegmenter(const SegmenterConfig& cfg) {
#ifdef PR_HAS_ONNX
  if (!cfg.modelPath.empty()) return std::make_unique<OnnxSegmenter>(cfg);
#endif
  return std::make_unique<ClassicSegmenter>(cfg);
}

}  // namespace pr
