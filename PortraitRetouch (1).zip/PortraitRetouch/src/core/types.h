#pragma once
#include <opencv2/core.hpp>

namespace pr {

// Tum degerler 0..1 araligindadir.
struct RetouchParams {
  float skinSmooth     = 0.50f;  // Cilt puruzsuzlugu (alcak frekans duzeltme)
  float blemishRemoval = 0.50f;  // Leke/sivilce onarimi (heal)
  float dodgeBurn      = 0.30f;  // Isik-golge dengeleme
  float teethWhiten    = 0.30f;  // Dis beyazlatma
  float eyeBrighten    = 0.30f;  // Goz parlatma
  float hairClean      = 0.30f;  // Sac temizleme (uc kilcik/puruz)
  float textureKeep    = 1.00f;  // Yuksek frekans (gozenek) carpani; 1 = oldugu gibi
};

// Maskeler dusuk cozunurlukte (AI cozunurlugu) tutulur; tam cozunurluge
// tile basina, goruntuyu rehber alan "guided filter" ile buyutulur.
// CV_8U, 255 = tam uye.
struct Masks {
  cv::Mat skin, face, eyes, teeth, hair, background;
  bool empty() const { return skin.empty(); }
};

}  // namespace pr
