#pragma once
#include "retouch.h"
#include "segmenter.h"
#include <atomic>
#include <filesystem>
#include <functional>
#include <string>
#include <vector>

namespace pr {

struct PipelineConfig {
  int decodeThreads  = 2;   // CPU: JPEG/TIFF decode
  int retouchThreads = 2;   // CPU: tile rotus (OpenCV kendi icinde de paralel)
  int encodeThreads  = 2;   // CPU/disk: encode + metadata
  int maxInFlight    = 4;   // ayni anda bellekte bulunabilecek en fazla fotograf
  int jpegQuality    = 95;
  SegmenterConfig seg;
  RetouchParams params;
};

class Pipeline {
 public:
  using Progress = std::function<void(size_t done, size_t total, const std::string& file,
                                      bool ok, const std::string& error)>;
  explicit Pipeline(PipelineConfig c) : cfg_(std::move(c)) {}

  // Bloklar; bitince veya iptalde doner. cancel true olursa yeni is alinmaz,
  // havadaki isler tamamlanir.
  void run(const std::vector<std::filesystem::path>& inputs, const std::filesystem::path& outDir,
           const Progress& cb, const std::atomic<bool>& cancel);

 private:
  PipelineConfig cfg_;
};

}  // namespace pr
