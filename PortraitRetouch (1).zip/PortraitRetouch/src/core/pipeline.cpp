#include "pipeline.h"
#include "bounded_queue.h"
#include "image_io.h"
#include "metadata.h"
#include <mutex>
#include <semaphore>
#include <thread>

namespace fs = std::filesystem;

namespace pr {
namespace {
struct Job {
  fs::path in, out;
  cv::Mat img, result;
  Masks masks;
  bool ok = true;
  std::string err;
};
}  // namespace

void Pipeline::run(const std::vector<fs::path>& inputs, const fs::path& outDir,
                   const Progress& cb, const std::atomic<bool>& cancel) {
  fs::create_directories(outDir);
  const size_t total = inputs.size();
  auto seg = makeSegmenter(cfg_.seg);
  Retoucher rt(cfg_.params);

  BoundedQueue<Job> q1(2), q2(2), q3(2);
  std::counting_semaphore<256> slots(std::min(cfg_.maxInFlight, 256));
  std::atomic<size_t> next{0}, done{0};
  std::atomic<int> decLeft{cfg_.decodeThreads}, rtLeft{cfg_.retouchThreads};
  std::mutex cbMu;

  auto fail = [](Job& j, const std::exception& e) { j.ok = false; j.err = e.what(); };
  std::vector<std::thread> th;

  // 1) DECODE (CPU) -- siradaki fotograf, onceki GPU'da islenirken hazirlanir.
  for (int i = 0; i < cfg_.decodeThreads; ++i)
    th.emplace_back([&] {
      while (!cancel) {
        const size_t idx = next.fetch_add(1);
        if (idx >= total) break;
        slots.acquire();
        Job j;
        j.in = inputs[idx];
        j.out = outDir / j.in.filename();
        try { j.img = readImage(j.in); } catch (const std::exception& e) { fail(j, e); }
        q1.push(std::move(j));
      }
      if (--decLeft == 0) q1.close();
    });

  // 2) AI SEGMENTASYON (GPU/NPU) -- tek is parcacigi, GPU'yu bogmaz.
  th.emplace_back([&] {
    Job j;
    while (q1.pop(j)) {
      if (j.ok) try { j.masks = seg->segment(j.img); } catch (const std::exception& e) { fail(j, e); }
      q2.push(std::move(j));
    }
    q2.close();
  });

  // 3) ROTUS (CPU, tile'li)
  for (int i = 0; i < cfg_.retouchThreads; ++i)
    th.emplace_back([&] {
      Job j;
      while (q2.pop(j)) {
        if (j.ok) try { j.result = rt.process(j.img, j.masks); } catch (const std::exception& e) { fail(j, e); }
        j.img.release();
        j.masks = Masks{};
        q3.push(std::move(j));
      }
      if (--rtLeft == 0) q3.close();
    });

  // 4) ENCODE + METADATA (CPU/disk)
  for (int i = 0; i < cfg_.encodeThreads; ++i)
    th.emplace_back([&] {
      Job j;
      while (q3.pop(j)) {
        if (j.ok) try {
          writeImage(j.out, j.result, cfg_.jpegQuality);
          copyMetadata(j.in, j.out);
        } catch (const std::exception& e) { fail(j, e); }
        j.result.release();
        const size_t d = ++done;
        {
          std::lock_guard lk(cbMu);
          if (cb) cb(d, total, j.in.filename().string(), j.ok, j.err);
        }
        slots.release();
      }
    });

  for (auto& t : th) t.join();
}

}  // namespace pr
