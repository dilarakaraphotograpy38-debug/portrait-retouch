#pragma once
#include <filesystem>
namespace pr {
// EXIF/IPTC/XMP/ICC'yi kaynaktan ciktiya tasir (Exiv2 yoksa hicbir sey yapmaz,
// false doner). Orientation = 1 yapilir (goruntu zaten donmus okundu).
bool copyMetadata(const std::filesystem::path& src, const std::filesystem::path& dst);
}
