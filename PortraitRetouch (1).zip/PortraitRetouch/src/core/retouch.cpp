#include "retouch.h"
#include "guided_filter.h"
#include <opencv2/imgproc.hpp>
#include <opencv2/photo.hpp>
#include <algorithm>
#include <cmath>

namespace pr {
namespace {

cv::Mat gray(const cv::Mat& bgr) { cv::Mat g; cv::cvtColor(bgr, g, cv::COLOR_BGR2GRAY); return g; }
cv::Mat to3(const cv::Mat& w) { cv::Mat o; cv::Mat c[] = {w, w, w}; cv::merge(c, 3, o); return o; }
cv::Mat clamp01(const cv::Mat& m) { cv::Mat o = cv::min(cv::max(m, 0.0), 1.0); return o; }

// a*(1-w) + b*w ; w tek kanalli 0..1
cv::Mat blend(const cv::Mat& a, const cv::Mat& b, const cv::Mat& w) {
  cv::Mat d, w3 = to3(w);
  cv::subtract(b, a, d);
  cv::multiply(d, w3, d);
  cv::add(a, d, d);
  return d;
}

// Buyuk sigmalarda hizli Gauss: kucult - bulaniklastir - buyut.
cv::Mat gauss(const cv::Mat& m, double s) {
  cv::Mat o;
  if (s <= 12.0) {
    cv::GaussianBlur(m, o, cv::Size(), s, s, cv::BORDER_REFLECT);
    return o;
  }
  const double f = s / 6.0;
  cv::Mat small;
  cv::resize(m, small, cv::Size(), 1.0 / f, 1.0 / f, cv::INTER_AREA);
  cv::GaussianBlur(small, small, cv::Size(), 6.0, 6.0, cv::BORDER_REFLECT);
  cv::resize(small, o, m.size(), 0, 0, cv::INTER_LINEAR);
  return o;
}

cv::Mat warpMask(const cv::Mat& low, const cv::Rect& ext, double sx, double sy, cv::Size dsize) {
  cv::Mat M = (cv::Mat_<double>(2, 3) << sx, 0, sx * ext.x + 0.5 * sx - 0.5,
                                         0, sy, sy * ext.y + 0.5 * sy - 0.5);
  cv::Mat out;
  cv::warpAffine(low, out, M, dsize, cv::INTER_LINEAR | cv::WARP_INVERSE_MAP, cv::BORDER_REPLICATE);
  return out;
}

}  // namespace

// ---------------------------------------------------------------- process
cv::Mat Retoucher::process(const cv::Mat& src, const Masks& m) const {
  CV_Assert((src.depth() == CV_8U || src.depth() == CV_16U) && src.channels() == 3);
  if (m.empty()) return src.clone();

  const int W = src.cols, H = src.rows;
  const cv::Size lowSize = m.skin.size();
  auto lowF = [&](const cv::Mat& x) {
    cv::Mat o;
    if (x.empty()) o = cv::Mat::zeros(lowSize, CV_32F);
    else x.convertTo(o, CV_32F, 1.0 / 255.0);
    return o;
  };
  const cv::Mat lSkin = lowF(m.skin), lEyes = lowF(m.eyes), lTeeth = lowF(m.teeth),
                lHair = lowF(m.hair), lBg = lowF(m.background);
  const double sx = double(lowSize.width) / W, sy = double(lowSize.height) / H;

  // Yuz boyutundan olcek: sigma tum tile'lar icin SABIT (dikis olmasin).
  double faceSize = 0;
  if (!m.face.empty()) {
    cv::Mat bin = m.face > 127, labels, stats, cen;
    int n = cv::connectedComponentsWithStats(bin, labels, stats, cen, 8, CV_32S);
    int best = 0;
    for (int i = 1; i < n; ++i) best = std::max(best, stats.at<int>(i, cv::CC_STAT_AREA));
    faceSize = std::sqrt(double(best) / (sx * sy));
  }
  if (faceSize < 50) faceSize = std::sqrt(double(cv::countNonZero(m.skin > 127)) / (sx * sy)) * 0.5;
  if (faceSize < 50) faceSize = 0.3 * std::max(W, H);
  const double sigma = std::clamp(0.008 * faceSize, 1.5, 40.0);
  const int halo = int(std::ceil(3.0 * sigma * 8.0 + 2.0 * sigma)) + 8;

  const double scale = src.depth() == CV_16U ? 1.0 / 65535.0 : 1.0 / 255.0;
  cv::Mat dst = src.clone();

  for (int ty = 0; ty < H; ty += tile_) {
    for (int tx = 0; tx < W; tx += tile_) {
      const cv::Rect core(tx, ty, std::min(tile_, W - tx), std::min(tile_, H - ty));
      const cv::Rect ext = cv::Rect(core.x - halo, core.y - halo, core.width + 2 * halo,
                                    core.height + 2 * halo) & cv::Rect(0, 0, W, H);
      TileMasks tm;
      tm.skin  = warpMask(lSkin,  ext, sx, sy, ext.size());
      tm.eyes  = warpMask(lEyes,  ext, sx, sy, ext.size());
      tm.teeth = warpMask(lTeeth, ext, sx, sy, ext.size());
      tm.hair  = warpMask(lHair,  ext, sx, sy, ext.size());
      tm.bg    = warpMask(lBg,    ext, sx, sy, ext.size());

      // Hicbir sey islenmeyecekse tile'i atla (hiz).
      cv::Mat any = tm.skin + tm.eyes + tm.teeth + tm.hair;
      double mx; cv::minMaxLoc(any, nullptr, &mx);
      if (mx < 0.02) continue;

      cv::Mat f;
      src(ext).convertTo(f, CV_32FC3, scale);
      processTile(f, tm, sigma);

      cv::Mat outU;
      f.convertTo(outU, src.type(), 1.0 / scale);  // saturate_cast ile kirpar
      const cv::Rect inner(core.x - ext.x, core.y - ext.y, core.width, core.height);
      outU(inner).copyTo(dst(core));
    }
  }
  return dst;
}

// ---------------------------------------------------------------- tile
void Retoucher::processTile(cv::Mat& img, TileMasks& m, double sigma) const {
  const cv::Mat g = gray(img);
  const int r = std::max(3, int(sigma));

  // Maskeleri goruntu kenarlarina oturt (guided filter), goz/dis cilt disi.
  cv::Mat skin = clamp01(guidedFilter(g, m.skin, r, 1e-3f));
  cv::Mat hair = clamp01(guidedFilter(g, m.hair, std::max(2, r / 2), 1e-3f));
  cv::Mat eyes = clamp01(m.eyes), teeth = clamp01(m.teeth);
  cv::Mat bg   = clamp01(guidedFilter(g, m.bg, std::max(2, r / 2), 1e-3f));
  cv::Mat notEyes = 1.0 - gauss(eyes, 1.0), notTeeth = 1.0 - gauss(teeth, 1.0);
  skin = skin.mul(notEyes).mul(notTeeth);

  if (p_.skinSmooth > 0 || p_.blemishRemoval > 0 || p_.dodgeBurn > 0) skinPass(img, skin, sigma);
  if (p_.teethWhiten > 0) teethPass(img, teeth);
  if (p_.eyeBrighten > 0) eyesPass(img, eyes, sigma);
  if (p_.hairClean > 0)   hairPass(img, hair, bg, sigma);
}

// Frekans ayrimi: low (renk/isik) duzeltilir, high (gozenek) AYNEN eklenir.
void Retoucher::skinPass(cv::Mat& img, const cv::Mat& skin, double sigma) const {
  const float k = p_.skinSmooth;
  cv::Mat low = gauss(img, sigma);
  cv::Mat high = img - low;

  cv::Mat res;
  {
    cv::Mat lowMix = low;
    if (k > 0) {
      const float eps = std::pow(0.015f + 0.08f * k, 2.0f);
      cv::Mat lowS = guidedFilterBGR(gray(low), low, std::max(2, int(sigma * 2)), eps);
      lowS = gauss(lowS, sigma * 1.2);
      lowMix = low + (lowS - low) * k;
    }
    res = lowMix + high * p_.textureKeep;
  }

  if (p_.blemishRemoval > 0) healSpots(img, res, high, skin, sigma);
  if (p_.dodgeBurn > 0) dodgeBurn(res, skin, sigma);

  img = blend(img, res, skin);
}

// Leke/sivilce: Lab'da koyu+kirmizi yerel sapmalari bul, Telea ile doldur,
// dokuyu komsu bolgeden (oteleme) klonla -> plastik gorunmez.
void Retoucher::healSpots(const cv::Mat& img, cv::Mat& res, const cv::Mat& high,
                          const cv::Mat& skin, double sigma) const {
  cv::Mat lab;
  cv::cvtColor(img, lab, cv::COLOR_BGR2Lab);  // float: L 0..100, a/b ~ -127..127
  std::vector<cv::Mat> ch;
  cv::split(lab, ch);
  const double s1 = std::max(1.0, sigma * 0.35), s2 = sigma * 2.0;
  cv::Mat L1 = gauss(ch[0], s1), L2 = gauss(ch[0], s2);
  cv::Mat a1 = gauss(ch[1], s1), a2 = gauss(ch[1], s2);
  cv::Mat score = (L2 - L1) / 100.0 + (a1 - a2) * (1.5 / 127.0);  // koyu ve/veya kirmizi -> +

  const float thr = 0.04f + 0.12f * (1.0f - p_.blemishRemoval);
  cv::Mat bin = (score > thr) & (skin > 0.5);

  cv::Mat labels, stats, cen;
  const int n = cv::connectedComponentsWithStats(bin, labels, stats, cen, 8, CV_32S);
  const double minA = CV_PI * std::pow(0.15 * sigma, 2.0), maxA = CV_PI * std::pow(2.5 * sigma, 2.0);
  std::vector<uchar> keep(n, 0);
  for (int i = 1; i < n; ++i) {
    const int a = stats.at<int>(i, cv::CC_STAT_AREA);
    keep[i] = (a >= minA && a <= maxA) ? 255 : 0;
  }
  cv::Mat spots(bin.size(), CV_8U, cv::Scalar(0));
  for (int y = 0; y < labels.rows; ++y) {
    const int* lp = labels.ptr<int>(y);
    uchar* sp = spots.ptr<uchar>(y);
    for (int x = 0; x < labels.cols; ++x) sp[x] = lp[x] > 0 ? keep[lp[x]] : 0;
  }
  if (cv::countNonZero(spots) == 0) return;

  const int rad = std::max(1, int(sigma * 0.4));
  cv::dilate(spots, spots, cv::getStructuringElement(cv::MORPH_ELLIPSE, {2 * rad + 1, 2 * rad + 1}));

  cv::Mat img8, filled8;
  img.convertTo(img8, CV_8UC3, 255.0);
  cv::inpaint(img8, spots, filled8, std::max(2.0, sigma * 0.4), cv::INPAINT_TELEA);
  cv::Mat filled;
  filled8.convertTo(filled, CV_32FC3, 1.0 / 255.0);
  cv::Mat fillLow = gauss(filled, sigma);

  // Komsu bolgeden doku klonla: high'i oteleyip ekle.
  cv::Mat T = (cv::Mat_<double>(2, 3) << 1, 0, sigma * 5.0, 0, 1, sigma * 3.0);
  cv::Mat shifted;
  cv::warpAffine(high, shifted, T, high.size(), cv::INTER_LINEAR, cv::BORDER_REFLECT);
  cv::Mat healed = fillLow + shifted * p_.textureKeep;

  cv::Mat soft;
  spots.convertTo(soft, CV_32F, 1.0 / 255.0);
  soft = gauss(soft, std::max(1.0, sigma * 0.3));
  soft = clamp01(soft * std::min(1.0f, p_.blemishRemoval * 1.2f));
  res = blend(res, healed, soft.mul(skin));
}

// Otomatik Dodge & Burn: yerel isigi cilt-agirlikli genis ortalamaya yaklastirir.
void Retoucher::dodgeBurn(cv::Mat& res, const cv::Mat& skin, double sigma) const {
  cv::Mat L = gray(res);
  cv::Mat Ll = gauss(L, sigma * 2.0);
  const double sb = sigma * 8.0;
  cv::Mat num = gauss(Ll.mul(skin), sb);
  cv::Mat den = gauss(skin, sb) + 1e-3;
  cv::Mat target;
  cv::divide(num, den, target);
  cv::Mat delta = (target - Ll) * p_.dodgeBurn;
  delta = cv::min(cv::max(delta, -0.06), 0.06);
  res = res + to3(delta);
}

void Retoucher::teethPass(cv::Mat& img, const cv::Mat& teeth) const {
  if (cv::countNonZero(teeth > 0.05) == 0) return;
  cv::Mat lab;
  cv::cvtColor(img, lab, cv::COLOR_BGR2Lab);
  std::vector<cv::Mat> c;
  cv::split(lab, c);
  c[2] = c[2] * 0.45;                         // sarilik azalt
  c[1] = c[1] * 0.85;
  c[0] = c[0] + (100.0 - c[0]) * 0.18;        // hafif aydinlat
  cv::merge(c, lab);
  cv::Mat whitened;
  cv::cvtColor(lab, whitened, cv::COLOR_Lab2BGR);
  cv::Mat w = clamp01(gauss(teeth, 1.0) * p_.teethWhiten);
  img = blend(img, whitened, w);
}

void Retoucher::eyesPass(cv::Mat& img, const cv::Mat& eyes, double sigma) const {
  if (cv::countNonZero(eyes > 0.05) == 0) return;
  cv::Mat lab;
  cv::cvtColor(img, lab, cv::COLOR_BGR2Lab);
  std::vector<cv::Mat> c;
  cv::split(lab, c);
  cv::Mat Lb = gauss(c[0], std::max(1.0, sigma * 0.6));
  c[0] = c[0] + 8.0 + 0.5 * (c[0] - Lb);      // parlaklik + yerel kontrast
  cv::merge(c, lab);
  cv::Mat bright;
  cv::cvtColor(lab, bright, cv::COLOR_Lab2BGR);
  cv::Mat w = clamp01(gauss(eyes, 1.0) * p_.eyeBrighten);
  img = blend(img, bright, w);
}

// Sac: (1) sac ici hafif kenar-koruyan puruzsuzlestirme, (2) sac/arka plan
// sinirinda ince uc kilciklari morfolojik kapama/acma ile siler.
void Retoucher::hairPass(cv::Mat& img, const cv::Mat& hair, const cv::Mat& bg, double sigma) const {
  if (cv::countNonZero(hair > 0.05) == 0) return;
  const float k = p_.hairClean;
  cv::Mat g = gray(img);
  cv::Mat smooth = guidedFilterBGR(g, img, std::max(2, int(sigma * 0.8)), std::pow(0.01f + 0.05f * k, 2.0f));
  cv::Mat out = blend(img, smooth, clamp01(hair * (0.6f * k)));

  cv::Mat hairBin = hair > 0.5;
  const int bandR = std::max(2, int(sigma * 2));
  cv::Mat dil, band;
  cv::dilate(hairBin, dil, cv::getStructuringElement(cv::MORPH_ELLIPSE, {2 * bandR + 1, 2 * bandR + 1}));
  band = dil;
  band.setTo(0, hairBin);
  cv::Mat bandF;
  band.convertTo(bandF, CV_32F, 1.0 / 255.0);
  bandF = gauss(bandF, std::max(1.0, sigma * 0.3)).mul(bg);

  cv::Scalar hairMean = cv::mean(g, hairBin);
  cv::Mat bgBin = (bg > 0.7) & (band == 0) & (hairBin == 0);
  cv::Scalar bgMean = cv::mean(g, bgBin);
  const int ks = std::max(3, int(sigma * 0.7)) | 1;
  cv::Mat kernel = cv::getStructuringElement(cv::MORPH_ELLIPSE, {ks, ks});
  cv::Mat cleaned;
  // Arka plan sacdan acik: ince koyu cizgiler -> kapama; koyu arka plan: ince acik cizgiler -> acma.
  cv::morphologyEx(out, cleaned, bgMean[0] > hairMean[0] ? cv::MORPH_CLOSE : cv::MORPH_OPEN, kernel);
  out = blend(out, cleaned, clamp01(bandF * (0.9f * k)));
  img = out;
}

}  // namespace pr
