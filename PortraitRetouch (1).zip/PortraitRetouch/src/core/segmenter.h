#pragma once
#include "types.h"
#include <memory>
#include <string>
#include <vector>

namespace pr {

// CelebAMask-HQ 19 sinifli yuz ayristirma (BiSeNet) icin varsayilan sinif haritasi.
// Baska bir model kullanirsan yalnizca bu listeleri degistir.
struct ClassMap {
  std::vector<int> skin  {1, 10, 14};   // cilt, burun, boyun
  std::vector<int> face  {1, 2, 3, 4, 5, 10, 11, 12, 13};
  std::vector<int> eyes  {4, 5};
  std::vector<int> teeth {11};          // "mouth" = agiz ici (dis)
  std::vector<int> hair  {17};
  std::vector<int> bg    {0};
};

struct SegmenterConfig {
  std::string modelPath;            // .onnx; bos ise klasik (modelsiz) yedek kullanilir
  std::string provider = "cpu";     // cpu | cuda | dml | coreml
  int  longSide = 1024;             // AI cozunurlugu (uzun kenar)
  bool bodySkin = true;             // yuz disindaki (kol, omuz) cildi renkle genislet
  ClassMap classes;
};

class ISegmenter {
 public:
  virtual ~ISegmenter() = default;
  // bgr: CV_8UC3 veya CV_16UC3. Maskeler en fazla longSide boyutundadir.
  virtual Masks segment(const cv::Mat& bgr) = 0;
};

std::unique_ptr<ISegmenter> makeSegmenter(const SegmenterConfig& cfg);

}  // namespace pr
