#pragma once
#include <opencv2/core.hpp>

namespace pr {
// I, p: CV_32FC1, ayni boyut. r: pencere yaricapi, eps: duzgunlestirme.
cv::Mat guidedFilter(const cv::Mat& I, const cv::Mat& p, int r, float eps);
// 3 kanalli goruntuyu tek kanalli (gri) rehberle filtreler.
cv::Mat guidedFilterBGR(const cv::Mat& guideGray, const cv::Mat& bgr, int r, float eps);
}
