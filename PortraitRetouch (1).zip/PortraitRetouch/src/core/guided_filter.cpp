#include "guided_filter.h"
#include <opencv2/imgproc.hpp>

namespace pr {

cv::Mat guidedFilter(const cv::Mat& I, const cv::Mat& p, int r, float eps) {
  CV_Assert(I.type() == CV_32FC1 && p.type() == CV_32FC1 && I.size() == p.size());
  const cv::Size k(2 * r + 1, 2 * r + 1);
  auto box = [&](const cv::Mat& m) {
    cv::Mat o;
    cv::boxFilter(m, o, CV_32F, k, cv::Point(-1, -1), true, cv::BORDER_REFLECT);
    return o;
  };
  cv::Mat mI = box(I), mp = box(p), mIp = box(I.mul(p)), mII = box(I.mul(I));
  cv::Mat varI = mII - mI.mul(mI);
  cv::Mat covIp = mIp - mI.mul(mp);
  cv::Mat denom = varI + static_cast<double>(eps);
  cv::Mat a;
  cv::divide(covIp, denom, a);
  cv::Mat b = mp - a.mul(mI);
  cv::Mat q = box(a).mul(I) + box(b);
  return q;
}

cv::Mat guidedFilterBGR(const cv::Mat& guideGray, const cv::Mat& bgr, int r, float eps) {
  CV_Assert(bgr.type() == CV_32FC3);
  std::vector<cv::Mat> ch(3);
  cv::split(bgr, ch);
  for (auto& c : ch) c = guidedFilter(guideGray, c, r, eps);
  cv::Mat out;
  cv::merge(ch, out);
  return out;
}

}  // namespace pr
